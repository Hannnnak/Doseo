package qna.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import qna.DAO.QnaDao;



public class ListQnaService {

}
