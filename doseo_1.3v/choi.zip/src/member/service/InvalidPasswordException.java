package member.service;

public class InvalidPasswordException extends RuntimeException{

}
