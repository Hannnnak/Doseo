package review.service;

public class ReviewContentNotFoundException extends RuntimeException {

}
