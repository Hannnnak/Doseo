package auth.service;

//p605
//로그인 실패
public class LoginFailException extends RuntimeException {

}
