package review.service;

public class RownumRequest {
	
	private int reviewNumber;

	public RownumRequest(int reviewNumber) {
		this.reviewNumber = reviewNumber;
		
	}

	public int getReviewNumber() {
		return reviewNumber;
	}
	
}
