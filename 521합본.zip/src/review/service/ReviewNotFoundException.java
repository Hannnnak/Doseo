package review.service;

public class ReviewNotFoundException extends RuntimeException {

}
