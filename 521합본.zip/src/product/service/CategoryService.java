package product.service;

import product.dao.ProductDao;

//카테고리 select해주는 서비스
//read
//dao와 연동
public class CategoryService {
	
	public String getCategory(String category) {
		return category;
	}
	


}
