package member.service;

public class ModifyRequest {
	//ModifyRequest는 유저가 입력한 폼(joinForm.jsp)의 내용을
	//이 클래스의 객체로 담아서
	//JoinService전달
	private String mname;
	private String mgender;
	private String mbirth;
	private String mphone1;
	private String mphone2;
	private String mphone3;
	private String memail;
	private String mfavorite1;
	private String mfavorite2;
	private String mfavorite3;
	private String maddress;
	private String mid;
	
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getMgender() {
		return mgender;
	}
	public void setMgender(String mgender) {
		this.mgender = mgender;
	}
	public String getMbirth() {
		return mbirth;
	}
	public void setMbirth(String mbirth) {
		this.mbirth = mbirth;
	}
	public String getMphone1() {
		return mphone1;
	}
	public void setMphone1(String mphone1) {
		this.mphone1 = mphone1;
	}
	public String getMphone2() {
		return mphone2;
	}
	public void setMphone2(String mphone2) {
		this.mphone2 = mphone2;
	}
	public String getMphone3() {
		return mphone3;
	}
	public void setMphone3(String mphone3) {
		this.mphone3 = mphone3;
	}
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getMfavorite1() {
		return mfavorite1;
	}
	public void setMfavorite1(String mfavorite1) {
		this.mfavorite1 = mfavorite1;
	}
	public String getMfavorite2() {
		return mfavorite2;
	}
	public void setMfavorite2(String mfavorite2) {
		this.mfavorite2 = mfavorite2;
	}
	public String getMfavorite3() {
		return mfavorite3;
	}
	public void setMfavorite3(String mfavorite3) {
		this.mfavorite3 = mfavorite3;
	}
	public String getMaddress() {
		return maddress;
	}
	public void setMaddress(String maddress) {
		this.maddress = maddress;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	

	
	
	
	
	
}
