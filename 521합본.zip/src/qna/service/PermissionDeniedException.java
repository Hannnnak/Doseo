package qna.service;

public class PermissionDeniedException extends RuntimeException {

}
