package product.service;

public class PermissionDeniedException extends RuntimeException {
	
	
}
