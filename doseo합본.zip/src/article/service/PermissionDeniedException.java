package article.service;

//p666
public class PermissionDeniedException extends RuntimeException {

}
