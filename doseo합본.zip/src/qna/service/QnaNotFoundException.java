package qna.service;

public class QnaNotFoundException extends RuntimeException {

}
