package cart.service;

public class ProductNotFoundException extends RuntimeException {

}
