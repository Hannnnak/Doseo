package auth.service;

//로그인 실패
public class LoginFailException extends RuntimeException {

}
